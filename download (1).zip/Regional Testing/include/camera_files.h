void start_camera();
void find_idealic_object_size_viacamera(int channel, int object_size, int smallest_distance, int largest_distance);
void find_idealic_object_size_viaET(int channel, int object_size, int port, int smallest_measurement, int largest_measurement);
