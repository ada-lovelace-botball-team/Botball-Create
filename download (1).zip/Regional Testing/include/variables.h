#define claw_up 1065
#define claw_water_cube 1868

#define TRUE 1
#define FALSE 0 