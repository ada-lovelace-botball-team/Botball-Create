#define TRUE 1
#define FALSE 0

void Sweepy_Thingie(int power, int servo);
void servo(int port, int desired_position);